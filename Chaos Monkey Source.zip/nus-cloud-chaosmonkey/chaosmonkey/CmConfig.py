class CmConfig:
    apiPort = 6000
    databaseHost = 'localhost'
    databaseUser = 'root'
    databasePassword = 'password'
    databaseName = 'chaosmonkey'