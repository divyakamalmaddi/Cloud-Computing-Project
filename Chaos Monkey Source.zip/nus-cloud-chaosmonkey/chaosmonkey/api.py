from CmConfig import CmConfig
import bottle
import json
import mysql.connector

def openDatabaseConnection():
    dbConnection = mysql.connector.connect(
        host=CmConfig.databaseHost,
        user=CmConfig.databaseUser,
        passwd=CmConfig.databasePassword,
        database=CmConfig.databaseName
    )
    return dbConnection


def closeDatabaseConnection(dbConnection):
    dbConnection.commit()
    dbConnection.close()


@bottle.route('/api/chaosmonkey/schedule/<userid>', method=['GET'])
def getSchedules(userid):
    dbConnection = openDatabaseConnection()
    cursor = dbConnection.cursor(dictionary=True)
    query = "SELECT id, date, time, app, account, region, stack, cluster FROM schedules WHERE account = {}".format(userid)
    print("[QUERY]", query)
    cursor.execute(query)
    schedules = cursor.fetchall()
    schedulesJson = []
    for schedule in schedules:
        schedulesJson.append({
            "schedule_id": schedule['id'],
            "schedule_date": schedule['date'],
            "schedule_time": schedule['time'],
            "schedule_app": schedule['app'],
            "schedule_account": schedule['account'],
            "schedule_region": schedule['region'],
            "schedule_stack": schedule['stack'],
            "schedule_cluster": schedule['cluster']
        })
    closeDatabaseConnection(dbConnection)
    return json.dumps(schedulesJson)


@bottle.route('/api/chaosmonkey/schedule/<userid>', method=['DELETE'])
def deleteSchedules(userid):
    dbConnection = openDatabaseConnection()
    cursor = dbConnection.cursor(dictionary=True)
    query = "DELETE FROM schedules WHERE account = {}".format(userid)
    print("[QUERY]", query)
    cursor.execute(query)
    closeDatabaseConnection(dbConnection)
    return {'result': 'OK'}


@bottle.route('/api/chaosmonkey/termination/<userid>', method=['GET'])
def getTerminations(userid):
    # Only GET method as this data is inserted by chaos monkeys cron job
    dbConnection = openDatabaseConnection()
    cursor = dbConnection.cursor(dictionary=True)
    query = "SELECT id, app, account, stack, cluster, region, asg, instance_id, killed_at, leashed FROM terminations WHERE account = {}".format(userid)
    print("[QUERY]", query)
    cursor.execute(query)
    terminations = cursor.fetchall()
    terminationsJson = []
    for termination in terminations:
        terminationsJson.append({
            "termination_id": termination['id'],
            "termination_app": termination['app'],
            "termination_account": termination['account'],
            "termination_stack": termination['stack'],
            "termination_cluster": termination['cluster'],
            "termination_region": termination['region'],
            "termination_asg": termination['asg'],
            "termination_instance_id": termination['instance_id'],
            "termination_killed_at": termination['killed_at'],
            "termination_leashed": termination['leashed'],
        })
    closeDatabaseConnection(dbConnection)
    return json.dumps(terminationsJson)


@bottle.route('/api/chaosmonkey/schedule', method=['POST', 'PUT'])
def addSchedule():
    dbConnection = openDatabaseConnection()
    scheduleData = bottle.request.json
    cursor = dbConnection.cursor()
    query = "INSERT INTO schedules " \
            "(date, time, app, account, region, stack, cluster) " \
            "VALUES (now(), now(), '{}', '{}', '{}', '{}', '{}')".format(scheduleData['app'], scheduleData['userid'], "DUMMY", "DUMMY", "DUMMY") # Dummy values are on purpose
    print("[QUERY]", query)
    cursor.execute(query)
    closeDatabaseConnection(dbConnection)
    return {'result': 'OK'}