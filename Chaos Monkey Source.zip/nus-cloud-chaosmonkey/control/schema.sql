-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema chaos_control
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema chaos_control
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `chaos_control` DEFAULT CHARACTER SET utf8 ;
USE `chaos_control` ;

-- -----------------------------------------------------
-- Table `chaos_control`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `chaos_control`.`customer` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL,
  `password` VARCHAR(32) NOT NULL,
  `zabbix_user_id` INT  NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `chaos_control`.`host_group`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `chaos_control`.`host_group` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL,
  `customer_id` INT NOT NULL,
  `zabbix_host_group_id` INT  NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_host_group_customer_idx` (`customer_id` ASC),
  CONSTRAINT `fk_host_group_customer`
    FOREIGN KEY (`customer_id`)
    REFERENCES `chaos_control`.`customer` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;



-- -----------------------------------------------------
-- Table `chaos_control`.`host`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `chaos_control`.`host` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `hostname` VARCHAR(45) NOT NULL,
  `ssh_port` INT NOT NULL,
  `ssh_username` VARCHAR(45) NOT NULL,
  `ssh_password` VARCHAR(45) NOT NULL,
  `host_group_id` INT NOT NULL,
  `zabbix_host_id` INT  NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_host_host_group_idx` (`host_group_id` ASC),
  CONSTRAINT `fk_host_host_group`
    FOREIGN KEY (`host_group_id`)
    REFERENCES `chaos_control`.`host_group` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `chaos_control`.`cm_schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `chaos_control`.`cm_schedule` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `start` DATETIME NOT NULL,
  `end` DATETIME NOT NULL,
  `host_group_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cm_schedule_host_group_idx` (`host_group_id` ASC),
  CONSTRAINT `fk_cm_schedule_host_group`
    FOREIGN KEY (`host_group_id`)
    REFERENCES `chaos_control`.`host_group` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
