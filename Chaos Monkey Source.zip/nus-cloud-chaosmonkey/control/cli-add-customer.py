from ControlConfig import ControlConfig
import hashlib
import json
import mysql.connector
import requests
import sys


def main(argv):
    if len(sys.argv) != 3:
        print("[usage]: <cli-add-customer.py> <username> <password>")
        sys.exit(1)

    username = sys.argv[1]
    passwd = sys.argv[2]
    strongPwd = hashlib.md5(passwd.encode()).hexdigest()

    url = ControlConfig.zabbixApiBaseUrl + '/zabbix/api_jsonrpc.php'
    headers = {"Content-Type": "application/json"}
    print(url)
    payload = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {
            "user": "Admin",
            "password": "zabbix"
        },
        "id": 1,
        "auth": None
    }
    response = requests.post(url, data=json.dumps(payload), headers=headers)

    loginStatus = response.status_code
    auth = response.json()['result']
    id = response.json()['id']

    if loginStatus == 200:
        userPayload={
            "jsonrpc": "2.0",
            "method": "user.create",
            "params": {
                "alias": username,
                "passwd": passwd,
                "usrgrps": [
                    {
                        "usrgrpid": ControlConfig.zabbixGroupId
                    }
                ],
                "user_medias": [
                    {
                        "mediatypeid": "1",
                        "sendto": [
                            "support@company.com"
                        ],
                        "active": 0,
                        "severity": 63,
                        "period": "1-7,00:00-24:00"
                    }
                ]
            },
            "auth": auth,
            "id": id
        }
        userResponse = requests.post(url, data=json.dumps(userPayload), headers=headers)

        users = userResponse.json()['result']
        userStatus = userResponse.status_code
        zabbixUserId = users['userids'][0]

    if userStatus == 200:
        dbConnection = mysql.connector.connect(
            host=ControlConfig.databaseHost,
            user=ControlConfig.databaseUser,
            passwd=ControlConfig.databasePassword,
            database=ControlConfig.databaseName
        )
        cursor = dbConnection.cursor()
        query = "INSERT INTO customer (name, password, zabbix_user_id) " \
                "VALUES ('{}', '{}', {}})".format(username, strongPwd, int(zabbixUserId))
        print("[QUERY]", query)
        cursor.execute(query)
        dbConnection.commit()
        dbConnection.close()


if __name__ == "__main__":
    main(sys.argv[1:])
