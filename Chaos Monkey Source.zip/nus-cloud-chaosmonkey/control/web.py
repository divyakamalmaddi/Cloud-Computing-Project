from ControlConfig import ControlConfig
import beaker.middleware
import bottle
import hashlib
import json
import mysql.connector
import requests
import socket

session_opts = {
    'session.type': 'file',
    'session.cookie_expires': 300,
    'session.data_dir': './data',
    'session.auto': True
}
app = beaker.middleware.SessionMiddleware(bottle.app(), session_opts)


def openDatabaseConnection():
    dbConnection = mysql.connector.connect(
        host=ControlConfig.databaseHost,
        user=ControlConfig.databaseUser,
        passwd=ControlConfig.databasePassword,
        database=ControlConfig.databaseName
    )
    return dbConnection


def closeDatabaseConnection(dbConnection):
    dbConnection.commit()
    dbConnection.close()


@bottle.route('/')
def loginScreen():
    html = bottle.template('login')
    return html


@bottle.route('/api/hostgroup')
def loginScreen():
    html = bottle.template('hostGroup')
    return html


@bottle.route('/api/host')
def loginScreen():
    html = bottle.template('host')
    return html


@bottle.route('/api/schedule')
def loginScreen():
    html = bottle.template('schedule')
    return html


@bottle.route('/api/login', method=['POST', 'PUT'])
def login():
    session = bottle.request.environ.get('beaker.session')

    username = bottle.request.forms.get("username")
    password = bottle.request.forms.get("password")
    strongpwd = hashlib.md5(password.encode()).hexdigest()

    dbConnection = openDatabaseConnection()

    cursor = dbConnection.cursor()
    query = "SELECT COUNT(1) FROM customer WHERE name=%s AND  password=%s"
    print("[QUERY] " + query)
    cursor.execute(query, (username, strongpwd))
    (result,) = cursor.fetchone()  # the comma is on purpos

    if result != 0:
        queryId = "SELECT id FROM customer WHERE name=%s AND  password=%s"
        cursor.execute(queryId, (username, strongpwd))
        (customerId,) = cursor.fetchone()  # the comma is on purpos
        closeDatabaseConnection(dbConnection)

    if result != 0:
        session['customerId'] = customerId
        session['loggedIn'] = True
        session.save()
        # html = bottle.template('hostGroup')
        # return html
        bottle.redirect('/api/overview')


@bottle.route('/api/overview')
def overview():
    session = bottle.request.environ.get('beaker.session')

    if session.get('loggedIn'):
        customerId = session.get('customerId')
        dbConnection = openDatabaseConnection()

        cursor = dbConnection.cursor(dictionary=True)
        query = "SELECT id, name, customer_id, zabbix_host_group_id FROM host_group WHERE customer_id=%s"
        print("[QUERY] " + query)
        cursor.execute(query, (int(customerId),))  # the comma is on purpos
        hostGroupCollection = cursor.fetchall()

        queryHost = "SELECT ht.id, ht.hostname, ht.ssh_port, ht.ssh_username," \
                    " ht.host_group_id, hg.zabbix_host_group_id, ht.zabbix_host_id " \
                    "FROM host ht, host_group hg " \
                    "WHERE ht.host_group_id = hg.id AND hg.customer_id=%s"
        print("[QUERY] " + queryHost)
        cursor.execute(queryHost, (int(customerId),))  # the comma is on purpos
        hostCollection = cursor.fetchall()

        querySchedule = "SELECT cms.id, cms.start, cms.end, cms.host_group_id " \
                        "FROM cm_schedule cms, host_group hg " \
                        "WHERE cms.host_group_id = hg.id AND hg.customer_id=%s"
        print("[QUERY] " + querySchedule)
        cursor.execute(querySchedule, (int(customerId),))  # the comma is on purpos
        scheduleCollection = cursor.fetchall()

        closeDatabaseConnection(dbConnection)
        html = bottle.template('overview', hostGroup=hostGroupCollection, hosts=hostCollection,
                               schedules=scheduleCollection, host=ControlConfig.zabbixApiBaseUrl)
        return html


@bottle.route('/api/hostgroup', method=['POST', 'PUT'])
def saveHostGroup():
    session = bottle.request.environ.get('beaker.session')

    if session.get('loggedIn'):
        print("you are logged in")
        print(session.get('customerId'))

        name = bottle.request.forms.get("groupname")
        customerId = bottle.request.forms.get("customerid")

        url = ControlConfig.zabbixApiBaseUrl + '/zabbix/api_jsonrpc.php'
        headers = {"Content-Type": "application/json"}
        print(url)
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": "Admin",
                "password": "zabbix"
            },
            "id": 1,
            "auth": None
        }
        response = requests.post(url, data=json.dumps(payload), headers=headers)

        loginStatus = response.status_code
        auth = response.json()['result']
        id = response.json()['id']

        if loginStatus == 200:
            groupPayload = {
                "jsonrpc": "2.0",
                "method": "hostgroup.create",
                "params": {
                    "name": name
                },
                "auth": auth,
                "id": 1
            }
            groupResponse = requests.post(url, data=json.dumps(groupPayload), headers=headers)
            groups = groupResponse.json()['result']
            groupStatus = groupResponse.status_code
            zabbixHostGroupId = groups['groupids'][0]

        if groupStatus == 200:
            dbConnection = openDatabaseConnection()

            cursor = dbConnection.cursor()
            query = "INSERT INTO host_group (name, customer_id, zabbix_host_group_id) " \
                    "VALUES (%s, %s, %s) "
            print("[QUERY] " + query)
            cursor.execute(query, (name, customerId, zabbixHostGroupId))
            closeDatabaseConnection(dbConnection)
            # html = bottle.template('host')
            # return html
            bottle.redirect('/api/overview')


@bottle.route('/api/host', method=['POST', 'PUT'])
def saveHost():
    session = bottle.request.environ.get('beaker.session')
    if session.get('loggedIn'):
        customerId = session.get('customerId')
        hostName = bottle.request.forms.get("hostname")
        sshPort = bottle.request.forms.get("port")
        sshUserName = bottle.request.forms.get("username")
        sshPassword = bottle.request.forms.get("password")
        hostGroupId = bottle.request.forms.get("hostgroupid")

        dbConnection = openDatabaseConnection()

        cursor = dbConnection.cursor()
        zabbixGroupQuery = " select zabbix_host_group_id from host_group where customer_id=%s and id=%s"
        cursor.execute(zabbixGroupQuery, (customerId, hostGroupId))
        (zabbixGroupId,) = cursor.fetchone()

        url = ControlConfig.zabbixApiBaseUrl + '/zabbix/api_jsonrpc.php'
        headers = {"Content-Type": "application/json"}
        print(url)
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": "Admin",
                "password": "zabbix"
            },
            "id": 1,
            "auth": None
        }
        response = requests.post(url, data=json.dumps(payload), headers=headers)

        loginStatus = response.status_code
        auth = response.json()['result']
        id = response.json()['id']

        if loginStatus == 200:
            hostPayload = {
                "jsonrpc": "2.0",
                "method": "host.create",
                "params": {
                    "host": hostName,
                    "interfaces": [{
                        "type": 1,
                        "main": 1,
                        "useip": 1,
                        "ip": hostNameResolver(hostName),
                        "dns": "",
                        "port": sshPort
                    }],
                    "groups": [
                        {
                            "groupid": zabbixGroupId
                        }
                    ]
                },
                    "templates": [
                {
                    "templateid": "10102"
                }
            ],
                "auth": auth,
                "id": 1
            }
            hostResponse = requests.post(url, data=json.dumps(hostPayload), headers=headers)
            print(hostResponse)
            print(hostResponse.content)
            hosts = hostResponse.json()['result']
            hostStatus = hostResponse.status_code
            zabbixHostId = hosts['hostids'][0]

        if hostStatus == 200:
            query = "INSERT INTO host (hostname, ssh_port, ssh_username, ssh_password, host_group_id, zabbix_host_id) " \
                    "VALUES (%s, %s, %s, %s, %s, %s) "
            print("[QUERY] " + query)
            cursor.execute(query, (hostName, sshPort, sshUserName, sshPassword, hostGroupId, zabbixHostId))
            closeDatabaseConnection(dbConnection)
            # html = bottle.template('schedule')
            # return html
            bottle.redirect('/api/overview')


@bottle.route('/api/schedule', method=['POST', 'PUT'])
def saveSchedule():
    start = bottle.request.forms.get("start")
    end = bottle.request.forms.get("end")
    hostGroupId = bottle.request.forms.get("hostgroupid")

    dbConnection = openDatabaseConnection()

    cursor = dbConnection.cursor()
    query = "INSERT INTO cm_schedule (start, end, host_group_id) " \
            "VALUES (%s, %s, %s) "
    print("[QUERY] " + query)
    cursor.execute(query, (start, end, hostGroupId))
    closeDatabaseConnection(dbConnection)

    bottle.redirect('/api/overview')


def hostNameResolver(hostname):
    try:
        ip = socket.gethostbyname(hostname)
        print(ip)
        return ip
    except:
        print("127.0.0.1")
        return "127.0.0.1"


host = '0.0.0.0'
bottle.run(host=host, port=ControlConfig.webPort, app=app)
print("[BOTTLE] " + host + ":" + ControlConfig.webPort)