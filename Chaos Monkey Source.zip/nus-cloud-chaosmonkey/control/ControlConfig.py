class ControlConfig:
    databaseHost = 'localhost'
    databaseUser = 'root'
    databasePassword = 'is5451'
    databaseName = 'chaos_control'
    webPort = 8080
    zabbixApiBaseUrl = 'http://54.166.245.206:80'
    zabbixGroupId = 13
